import io.restassured.RestAssured;
import io.restassured.response.Response;
import org.json.JSONObject;
import org.testng.annotations.Test;

import static org.hamcrest.Matchers.*;

public class API_Testing {

    @Test
    public void GETUser(){
        //send request
        Response response = RestAssured
                .given()
                .baseUri("https://reqres.in")
                .when()
                .get("/api/users/2");

        System.out.println("GET Response\n" + response.asPrettyString());
        //validate response
        response.then().statusCode(200);
        response.then().body("data.first_name", endsWith("net"));
    }

    @Test
    public void POSTUser(){
        JSONObject postParams = new JSONObject();
        postParams.put("Name" , "Hassan");
        postParams.put("Job" , "leader");

        Response response = RestAssured
                .given()
                .baseUri("https://reqres.in")
                .header("Content-Type" , "application/json")
                //token to set in headers
                .header("x-api-key" , "reqres-free-v1")
                .body(postParams.toString())
                .when()
                .post("/api/user");

        System.out.println("User created successfully\n" + response.asPrettyString());

    }

    @Test
    public void PUTUser(){
        JSONObject putParams = new JSONObject();
        putParams.put("Name" , "Hassan Malik");
        putParams.put("Job" , "Zion leader");

        Response response = RestAssured
                .given()
                .baseUri("https://reqres.in")
                .header("Content-Type" , "application/json")
                .header("x-api-key","reqres-free-v1")
                .body(putParams.toString())
                .when().put("/api/users/2");

        System.out.println("updated :\n" + response.asPrettyString());
        response.then().statusCode(200);
        response.then().body("Name", startsWith("Hassan"));
    }

    @Test
    public void DELETEUser(){
        Response delete = RestAssured
                .given()
                .baseUri("https://reqres.in")
                .when().delete("/api/users/2");

        System.out.println("DELETE status code: " + delete.getStatusCode());
    }
}
