package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.support.PageFactory;
import org.openqa.selenium.By;

public class dashboardPage {
    WebDriver driver;

    public dashboardPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    public void logout(){
        driver.findElement(By.className("oxd-userdropdown-name")).click();
        driver.findElement(By.xpath("//a[text()='Logout']")).click();
    }

    public boolean isAtHomePage() {
        return driver.getCurrentUrl().contains("auth/login");
    }
}
