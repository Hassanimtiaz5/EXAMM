package tests;

import config.ConfigReader;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import pages.loginPage;
import pages.dashboardPage;

import java.util.Set;

public class Test_LoginFlow {

    WebDriver driver;
    loginPage loginPage;
    dashboardPage dashboardPage;

    @BeforeClass
    public void setUp(){
        driver = new ChromeDriver();

        // Step 1: Launch the Chrome Browser and Maximize the window
        driver.manage().window().maximize();

        // Step 2: Navigate to URL
        driver.get(ConfigReader.getProperty("url"));
        System.out.println("Launched URL by: L1F21BSSE0001");
    }

    @Test(priority = 1)
    public void loginTest(){
        loginPage = new loginPage(driver);

        // Step 3: Verify Login Page is loaded
        assert loginPage.isLoginPageLoaded();
        System.out.println("Login Page loaded successfully");

        // Step 4: Login to the application and then minimize the window
        loginPage.login(ConfigReader.getProperty("username"), ConfigReader.getProperty("password"));
        driver.manage().window().minimize();

        // Step 5: Retrieve all cookies after login
        Set<Cookie> cookies = driver.manage().getCookies();

        // Step 6: Print all cookie details
        for (Cookie cookie : cookies) {
            System.out.println("Cookie Name: " + cookie.getName());
            System.out.println("Cookie Value: " + cookie.getValue());
            System.out.println("Cookie Domain: " + cookie.getDomain());
            System.out.println("--------------------------");
        }

        // Step 7: Get a specific cookie
        Cookie selectedCookie = driver.manage().getCookieNamed("orangehrm");
        if (selectedCookie != null) {
            System.out.println("Selected Cookie:");
            System.out.println("Name: " + selectedCookie.getName());
            System.out.println("Value: " + selectedCookie.getValue());
            System.out.println("Reason: Tracking session data - Hassan Malik");
        }
    }

    @Test(priority = 2)
    public void logoutAndVerify() {
        // Step 8: Maximize and logout
        driver.manage().window().maximize();
        dashboardPage = new dashboardPage(driver);
        dashboardPage.logout();

        // Step 9: Verify directed to homepage
        assert dashboardPage.isAtHomePage();
        System.out.println("Returned to homepage after logout");

        // Step 10: Print section and full name
        System.out.println("Section: S5 | Full Name: Hassan Malik");
    }

    @AfterClass
    public void tearDown() {
        driver.quit();
    }
}
