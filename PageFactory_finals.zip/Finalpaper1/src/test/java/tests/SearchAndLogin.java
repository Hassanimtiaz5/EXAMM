package tests;

import base.BaseTest;
import config.ConfigReader;
import org.testng.Assert;
import org.testng.annotations.Test;
import pages.ProductPage;
import pages.SignupPage;

public class SearchAndLogin extends BaseTest {
    @Test
    public void testLogin(){
    ProductPage productpage = new ProductPage(driver);
    SignupPage signupPage = new SignupPage(driver);

    //using values from config.properties
        String productsUrl = ConfigReader.getProperty("productsUrl");
    String signupUrl = ConfigReader.getProperty("signupUrl");

    String name =  ConfigReader.getProperty("name");
    String email = ConfigReader.getProperty("email");
    String query = ConfigReader.getProperty("searchQuery");

    //calling method from HomePage
        driver.navigate().to(productsUrl);
        productpage.search(query);
        driver.navigate().to(signupUrl);
        signupPage.signup(name , email);

        //Assertions to verify results
Assert.assertTrue(driver.getPageSource().equals("Searched Products") ,
        "Search result text not found on page");
Assert.assertTrue(driver.getTitle().contains("Signup") ,
        "Page title does not contain 'Signup'");

    }
}
