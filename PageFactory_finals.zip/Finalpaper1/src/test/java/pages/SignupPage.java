package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class SignupPage {
    WebDriver driver;

    //locate webElements
  @FindBy(name = "name")
    WebElement nameField;

  @FindBy(xpath = "//input[@data-qa='signup-email']")
    WebElement emailField;

  @FindBy(xpath = "//button[@data-qa='signup-button']")
  WebElement signupBtn;
  //constructor
    public SignupPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver , this);
    }

    //actions
    public void signup(String name , String email){
        nameField.sendKeys(name);
        emailField.sendKeys(email);
        signupBtn.click();
    }
}
