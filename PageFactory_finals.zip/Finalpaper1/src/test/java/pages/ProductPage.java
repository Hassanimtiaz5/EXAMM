package pages;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class ProductPage {
    WebDriver driver;

    //locate search box and searchButton
    @FindBy(id = "search_product")
    WebElement searchBox;

    @FindBy(id = "submit_search")
    WebElement searchButton;

    //initialize webElements
    public ProductPage(WebDriver driver){
        this.driver = driver;
        PageFactory.initElements(driver , this);
    }


    //Actions to perform search operation
    public void search(String query){
        searchBox.sendKeys(query);
        searchButton.click();
    }
}
