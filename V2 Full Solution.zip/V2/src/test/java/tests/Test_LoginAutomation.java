package tests;

import config.ConfigReader;
import org.openqa.selenium.Cookie;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.*;
import pages.LoginPage;
import pages.DashboardPage;

import java.util.Set;

public class Test_LoginAutomation {

    WebDriver driver;
    LoginPage loginPage;
    DashboardPage dashboardPage;

    @BeforeClass
    public void setup() {
        // Step 1: Launch the Chrome Browser and Maximize the window
        driver = new ChromeDriver();
        driver.manage().window().maximize();

        // Step 2: Navigate to the URL and Print Reg. #
        driver.get(ConfigReader.getProperty("url"));
        System.out.println("URL launched successfully - L1F21BSSE0001");
    }

    @Test(priority = 1)
    public void loginTest() {
        loginPage = new LoginPage(driver);

        // Step 3: Verify that the Login Page is loaded successfully
        assert loginPage.isLoginPageDisplayed();
        System.out.println("Login Page loaded successfully");

        // Step 4: Login to the application and then minimize the window
        loginPage.login(ConfigReader.getProperty("username"), ConfigReader.getProperty("password"));
        driver.manage().window().minimize();

        // Step 5: Retrieve all cookies after login
        Set<Cookie> allCookies = driver.manage().getCookies();

        // Step 6: Print cookies details including Name, Value, and Domain
        for (Cookie cookie : allCookies) {
            System.out.println("Cookie Name: " + cookie.getName());
            System.out.println("Cookie Value: " + cookie.getValue());
            System.out.println("Cookie Domain: " + cookie.getDomain());
            System.out.println("--------");
        }

        // Step 7: Get and then print a specific cookie's Name and Value
        Cookie selectedCookie = driver.manage().getCookieNamed("orangehrm");
        if (selectedCookie != null) {
            System.out.println("Selected Cookie: " + selectedCookie.getName());
            System.out.println("Selected Value: " + selectedCookie.getValue());
            System.out.println("Reason: Session tracking for HRM system - Hassan Malik");
        }
    }

    @Test(priority = 2)
    public void logoutTest() {
        driver.manage().window().maximize();  // Step 8: Maximize window

        dashboardPage = new DashboardPage(driver);
        dashboardPage.logout();               // Perform logout

        // Step 9: Verify redirected to login page and close browser
        assert dashboardPage.isBackToLoginPage();
        System.out.println("Successfully returned to login page after logout.");
    }

    @AfterClass
    public void tearDown() {
        // Step 10: Print Section & Full Name
        System.out.println("Section: S5 | Full Name: Hassan Malik");
        driver.quit();
    }
}
